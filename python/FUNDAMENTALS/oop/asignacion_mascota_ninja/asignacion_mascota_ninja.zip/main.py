from ninja import Ninja
from mascota import Mascota

Alexandra = Ninja('Alexandra','Tamblay', 100, 100, 'charlotte')
charlotte = Mascota('charlotte','gato','churu')

charlotte.comer()
charlotte.dormir()
charlotte.Mostrar_energia()
charlotte.Mostrar_salud()
